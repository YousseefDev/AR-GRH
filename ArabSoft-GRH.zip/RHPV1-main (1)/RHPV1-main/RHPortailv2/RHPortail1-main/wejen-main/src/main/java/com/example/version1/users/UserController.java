package com.example.version1.users;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/users")
@RequiredArgsConstructor
                    public class UserController {

    private final UserRepository userRepository;

    @GetMapping("/profile")
    public ResponseEntity<User> getUserProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUserName = authentication.getName();
        return userRepository.findByEmail(currentUserName)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserProfileById(@PathVariable Long id) {
        return userRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }


    @PatchMapping("/profile/{userId}")
    public ResponseEntity<User> updateUserProfile(@PathVariable Long userId, @RequestBody User updatedUser) {
        return userRepository.findById(userId)
                .map(user -> {
                    if (updatedUser.getPhoneNumber() != null) {
                        user.setPhoneNumber(updatedUser.getPhoneNumber());
                    }
                    if (updatedUser.getDateOfBirth() != null) {
                        user.setDateOfBirth(updatedUser.getDateOfBirth());
                    }
                    if (updatedUser.getAddress() != null) {
                        user.setAddress(updatedUser.getAddress());
                    }
                    if (updatedUser.getCity() != null) {
                        user.setCity(updatedUser.getCity());
                    }
                    if (updatedUser.getState() != null) {
                        user.setState(updatedUser.getState());
                    }
                    if (updatedUser.getCountry() != null) {
                        user.setCountry(updatedUser.getCountry());
                    }
                    if (updatedUser.getPostalCode() != null) {
                        user.setPostalCode(updatedUser.getPostalCode());
                    }
                    if (updatedUser.getGender() != null) {
                        user.setGender(updatedUser.getGender());
                    }
                    if (updatedUser.getNationality() != null) {
                        user.setNationality(updatedUser.getNationality());
                    }
                    if (updatedUser.getMaritalStatus() != null) {
                        user.setMaritalStatus(updatedUser.getMaritalStatus());
                    }
                    if (updatedUser.getDepartment() != null) {
                        user.setDepartment(updatedUser.getDepartment());
                    }
                    if (updatedUser.getJobTitle() != null) {
                        user.setJobTitle(updatedUser.getJobTitle());
                    }
                    userRepository.save(user);
                    return ResponseEntity.ok(user);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
