package com.example.version1.requests.document;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name = "document_requests")
@Getter
@Setter
public class DocumentRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "document_type")
    private String documentType;

    @Column(name = "reason")
    private String reason;

    @Column(name = "status", columnDefinition = "VARCHAR(255) DEFAULT 'pending'") // Set default status to 'pending'
    private String status;

    @Column (name="response")
    private String response = "Request still under review";
}
