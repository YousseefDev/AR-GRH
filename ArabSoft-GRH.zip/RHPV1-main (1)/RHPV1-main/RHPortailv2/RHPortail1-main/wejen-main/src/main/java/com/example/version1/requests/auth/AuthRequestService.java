// AuthRequestService.java
package com.example.version1.requests.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthRequestService {

    @Autowired
    private AuthRequestRepository authRequestRepository;

    public AuthRequest createAuthRequest(AuthRequest request, Long userId) {
        request.setUserId(userId);
        return authRequestRepository.save(request);
    }
    public List<AuthRequest> getAllAuthRequests() {
        return authRequestRepository.findAll();
    }

    public List<AuthRequest> getPendingAuthRequests() {
            return authRequestRepository.findByStatus("pending");
    }
    public AuthRequest updateAuthRequestStatusAndResponse(Long id, String newStatus, String response) {
        AuthRequest request = authRequestRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Auth request not found with ID: " + id));

        request.setStatus(newStatus);
        request.setResponse(response);

        return authRequestRepository.save(request);
    }
    public List<AuthRequest> getAuthRequestsByUserId(Long userId) {
        return authRequestRepository.findByUserId(userId);
    }

    public int countPendingAuthRequests() {
        return authRequestRepository.countByStatus("pending");

    }
}
