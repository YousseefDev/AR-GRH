package com.example.version1.Hr;

import com.example.version1.requests.auth.AuthRequest;
import com.example.version1.requests.auth.AuthRequestService;
import com.example.version1.requests.document.DocumentRequest;
import com.example.version1.requests.document.DocumentRequestService;
import com.example.version1.requests.loan.LoanRequest;
import com.example.version1.requests.loan.LoanRequestService;
import com.example.version1.requests.personal.PersonalSituationRequest;
import com.example.version1.requests.personal.PersonalSituationRequestService;
import com.example.version1.requests.Leave.LeaveRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.naming.AuthenticationException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/requests/hr")
public class HRRequestController {

    @Autowired
    private LoanRequestService loanRequestService;

    @Autowired
    private PersonalSituationRequestService personalSituationRequestService;

    @Autowired
    private DocumentRequestService documentRequestService;



    // Loan Requests
    @GetMapping("/loan-requests")
    public ResponseEntity<List<LoanRequest>> getLoanRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<LoanRequest> loanRequests = loanRequestService.getAllLoanRequests();
        return new ResponseEntity<>(loanRequests, HttpStatus.OK);
    }

    @GetMapping("/loan-requestsx")
    public ResponseEntity<List<LoanRequest>> getPendingLoanRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<LoanRequest> loanRequests = loanRequestService.getPendingLoanRequests();
        return new ResponseEntity<>(loanRequests, HttpStatus.OK);
    }

    @GetMapping("/loan-requests/pending/count")
    public ResponseEntity<Integer> countPendingLoanRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        int count = loanRequestService.countPendingLoanRequests();
        return new ResponseEntity<>(count, HttpStatus.OK);
    }

    // Personal Situation Requests
    @GetMapping("/personal-situation-requests")
    public ResponseEntity<List<PersonalSituationRequest>> getPersonalSituationRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<PersonalSituationRequest> personalSituationRequests = personalSituationRequestService.getAllPersonalSituationRequests();
        return new ResponseEntity<>(personalSituationRequests, HttpStatus.OK);
    }

    @GetMapping("/personal-situation-requests/pending")
    public ResponseEntity<List<PersonalSituationRequest>> getPendingPersonalSituationRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<PersonalSituationRequest> personalSituationRequests = personalSituationRequestService.getPendingPersonalSituationRequests();
        return new ResponseEntity<>(personalSituationRequests, HttpStatus.OK);
    }

    @GetMapping("/personal-situation-requests/pending/count")
    public ResponseEntity<Integer> countPendingPersonalSituationRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        int count = personalSituationRequestService.countPendingPersonalSituationRequests();
        return new ResponseEntity<>(count, HttpStatus.OK);
    }

    // Document Requests
    @GetMapping("/document-requests")
    public ResponseEntity<List<DocumentRequest>> getDocumentRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<DocumentRequest> documentRequests = documentRequestService.getAllDocumentRequests();
        return new ResponseEntity<>(documentRequests, HttpStatus.OK);
    }

    @GetMapping("/document-requests/pending")
    public ResponseEntity<List<DocumentRequest>> getPendingDocumentRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        List<DocumentRequest> documentRequests = documentRequestService.getPendingDocumentRequests();
        return new ResponseEntity<>(documentRequests, HttpStatus.OK);
    }

    @GetMapping("/document-requests/pending/count")
    public ResponseEntity<Integer> countPendingDocumentRequests(Authentication authentication) throws AuthenticationException {
        validateAuthentication(authentication);
        int count = documentRequestService.countPendingDocumentRequests();
        return new ResponseEntity<>(count, HttpStatus.OK);
    }





    private void validateAuthentication(Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("User not authenticated");
        }
    }
}
