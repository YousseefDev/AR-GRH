export interface Attendance {
    id: number;
    date: string; // Adjust date format as per backend (e.g., ISO string)
    checkInTime: string; // Adjust time format as per backend (e.g., HH:mm:ss)
    checkOutTime: string | null; // Nullable if check-out not done yet
  }
  