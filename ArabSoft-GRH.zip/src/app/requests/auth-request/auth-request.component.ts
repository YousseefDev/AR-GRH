// auth-request.component.ts
import { Component } from '@angular/core';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth-request',
  templateUrl: './auth-request.component.html',
  styleUrls: ['./auth-request.component.scss']
})
export class AuthRequestComponent {
  authRequest: any = {
    type: '',
    reason: '',
    status: 'Pending' // Default status set to 'Pending'
  };
  requestStatus: string | null = null; // Variable to store request status


  constructor(private apiService: ApiService, private router: Router) {}

  submitAuthRequest(): void {
    this.apiService.createAuthRequest(this.authRequest).subscribe(
      (response) => {
        console.log('Authorization request created successfully:', response);
        this.requestStatus = 'Demande envoyer'; // Set success message

        this.router.navigate(['/employee']);
      },
      (error) => {
        console.error('Error creating authorization request:', error);
        // Handle error (e.g., display error message to user)
      }
    );
  }
}
