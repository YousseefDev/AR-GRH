import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.scss']
})
export class EmployeeDashboardComponent {
  showMenu: boolean = false;
  selectedRequestType: string | null = null;
  showProfile: boolean = false;
  userId: number;
  attendanceRecords: Attendance[] = [];
  showRequests: boolean = false;
  showPresence: boolean = false;

  constructor(private router: Router,
              private authService: AuthService,
              private apiService: ApiService) {
    this.userId = 1;
  }

  toggleMenu(): void {
    this.showMenu = !this.showMenu;
  }

  request(): void {
    this.showRequests = !this.showRequests;
    this.showProfile = false;
    this.showPresence = false;
  }

  selectRequestType(requestType: string): void {
    this.selectedRequestType = requestType;
    this.showMenu = false; // Fermer le menu une fois qu'une demande est sélectionnée
    this.showProfile = false;
  }

  showUserProfile(): void {
    this.showProfile = true;
    this.showPresence = false;
    this.selectedRequestType = null;
    this.showRequests = false;
  }

  togglePresence(): void {
    this.showPresence = !this.showPresence;
    this.showProfile = false;
    this.selectedRequestType = null;
    this.showRequests = false;
  }

  logout(): void {
    this.authService.logout();
  }

  ngOnInit(): void {
    this.fetchAttendance();
  }

  fetchMyRequest(): void {
    this.apiService.getMyRequests().subscribe();
    this.hideAttendance();
    this.showProfile = false;

  }
  hideAttendance(): void {
    this.showPresence = false;
  }

  fetchAttendance(): void {
    this.apiService.getUserAttendance(this.userId).subscribe(
      attendanceRecords => {
        this.attendanceRecords = attendanceRecords;
      },
      error => {
        console.error('Error fetching attendance records:', error);
      }
    );
    this.hideAttendance();
    this.showProfile = false;

  }
}

interface Attendance {
  id: number;
  user: User;
  date: string;
  checkInTime: string;
  checkOutTime: string;
}

interface User {
  id: number;
  fullName: string;
  email: string;
  // Add other user properties as needed
}
